# 六角學院 2023 軟體工程師體驗營－切版作業一
作業連結：[切版任務作業二－AI 工具王](https://rpg.hexschool.com/training/35/task)

## Table of contents

## Overview
- 第一次總共花費約 23 小時，1.5 小時完成大架構，21.5 小時進行 HTML、CSS 調整
- 第二次總共花費約 2.5 小時，針對助教回饋修改並修正 price.html 程式碼

### Link
- Live Site URL: [AI 工具王](https://chunjull.github.io/hexschool-web-camp-task-2/)

## My process
### Built with
- Semantic HTML5 markup
- CSS custom properties
- Responsive Web Design
- JavaScript

### What I learned
